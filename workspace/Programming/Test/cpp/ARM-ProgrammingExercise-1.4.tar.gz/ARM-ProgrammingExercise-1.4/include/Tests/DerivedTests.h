/*
 * DerivedTypeTests.h
 *
 *  Created on: Jul 28, 2022
 *      Author: ysiyer
 */

#ifndef INCLUDE_TESTS_DERIVEDTESTS_H_
#define INCLUDE_TESTS_DERIVEDTESTS_H_


void TestDerivedPtr();


#endif /* INCLUDE_TESTS_DERIVEDTESTS_H_ */
