/*
 * StructPointTypesTest.h
 *
 *  Created on: Jul 28, 2022
 *      Author: ysiyer
 */

#ifndef INCLUDE_TESTS_STRUCTPOINTTYPETESTS_H_
#define INCLUDE_TESTS_STRUCTPOINTTYPETESTS_H_


void TestStructPointTypePtr();


#endif /* INCLUDE_TESTS_STRUCTPOINTTYPETESTS_H_ */
