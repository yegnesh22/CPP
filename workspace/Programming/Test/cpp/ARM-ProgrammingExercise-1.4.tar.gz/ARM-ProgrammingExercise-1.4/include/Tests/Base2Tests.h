/*
 * Base2TypeTests.h
 *
 *  Created on: Jul 28, 2022
 *      Author: ysiyer
 */

#ifndef INCLUDE_TESTS_BASE2TESTS_H_
#define INCLUDE_TESTS_BASE2TESTS_H_

void TestBase2Ptr();



#endif /* INCLUDE_TESTS_BASE2TESTS_H_ */
