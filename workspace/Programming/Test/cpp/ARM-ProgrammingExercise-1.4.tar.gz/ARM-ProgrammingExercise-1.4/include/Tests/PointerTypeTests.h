/*
 * PointerTypeTests.h
 *
 *  Created on: Jul 28, 2022
 *      Author: ysiyer
 */

#ifndef INCLUDE_POINTERTYPETESTS_H_
#define INCLUDE_POINTERTYPETESTS_H_


void TestPointerTypeVar();


#endif /* INCLUDE_POINTERTYPETESTS_H_ */
