/*
 * FixedStringTypeTests.h
 *
 *  Created on: Jul 28, 2022
 *      Author: ysiyer
 */

#ifndef INCLUDE_TESTS_FIXEDSTRINGTYPETESTS_H_
#define INCLUDE_TESTS_FIXEDSTRINGTYPETESTS_H_


void TestFixedStringTypePtr();


#endif /* INCLUDE_TESTS_FIXEDSTRINGTYPETESTS_H_ */
