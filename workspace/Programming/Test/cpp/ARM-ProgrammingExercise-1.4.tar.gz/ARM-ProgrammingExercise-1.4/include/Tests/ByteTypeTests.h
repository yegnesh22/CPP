/*
 * ByteTests.h
 *
 *  Created on: Jul 28, 2022
 *      Author: ysiyer
 */

#ifndef INCLUDE_BYTETYPETESTS_H_
#define INCLUDE_BYTETYPETESTS_H_

void TestByteTypeVar();
void TestByteTypePtr();
void TestByteTypeMulti();

#endif /* INCLUDE_BYTETESTS_H_ */
